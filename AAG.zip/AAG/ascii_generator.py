from pyfiglet import Figlet
import sys

def print_ascii_art(text, font='slant'):
    """
    Convert the given text to ASCII art using the specified font.
    
    :param text: Text to convert to ASCII art.
    :param font: Font style for the ASCII art.
    """
    try:
        figlet = Figlet(font=font)
        ascii_art = figlet.renderText(text)
        print(ascii_art)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)

def choose_font():
    """
    Display font options and get the user's choice.
    
    :return: Selected font style.
    """
    fonts = ['slant', 'block', 'starwars']
    print("\nAvailable fonts:")
    for index, font in enumerate(fonts, start=1):
        print(f"{index}. {font}")
    
    while True:
        choice = input("Choose a font by entering the corresponding number or type 'exit' to quit: ").strip()
        
        if choice.lower() == 'exit':
            return None
        
        try:
            choice = int(choice)
            if 1 <= choice <= len(fonts):
                return fonts[choice - 1]
            else:
                print("Invalid choice. Please select a number from the list.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def main():
    """
    Main function to handle user input and print ASCII art.
    """
    print("Welcome to the ASCII Art Generator!")

    while True:
        print("\nSelect a font for the ASCII art:")
        font = choose_font()
        
        if font is None:
            print("Exiting the ASCII Art Generator. Goodbye!")
            break
        
        user_input = input(f"Enter the text you want to convert to ASCII art using the '{font}' font (or type 'exit' to quit): ").strip()
        
        if user_input.lower() == 'exit':
            print("Exiting the ASCII Art Generator. Goodbye!")
            break
        
        if user_input:
            print_ascii_art(user_input, font)
        else:
            print("Error: No text provided.", file=sys.stderr)

if __name__ == "__main__":
    main()
